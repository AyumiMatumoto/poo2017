/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio1;

public class Gerente extends Funcionario {
  private int senha;
  private int numeroDeFuncionariosGerenciados;

    public Gerente(String nome, String cpf, double salario) {
        super(nome, cpf, salario);
    }
    public Gerente(String nome, String cpf, double salario, int senha) {
        super(nome, cpf, salario);
        this.senha=senha;
    }
    
    
  public boolean autentica(int senha) {
    if (this.senha == senha) {
      return true;
    } else {
      return false;
    }
  }
  
  @Override
  // reescrita de código
  public double getBonificacao() {
    this.salario += this.salario * 0.15;
    return this.salario;
  }

    public void setSenha(int senha) {
        this.senha = senha;
    }

    public void setNumeroDeFuncionariosGerenciados(int numeroDeFuncionariosGerenciados) {
        this.numeroDeFuncionariosGerenciados = numeroDeFuncionariosGerenciados;
    }

    public int getSenha() {
        return senha;
    }

    public int getNumeroDeFuncionariosGerenciados() {
        return numeroDeFuncionariosGerenciados;
    }
}
