/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio1;

import java.util.Date;

/**
 *
 * @author IFSP
 */
public class Venda {
    private Funcionario funcionario;
    private Date data;
    private double valor;
    

    public Venda(Funcionario funcionario, Date data, double valor) {
        this.funcionario = funcionario;
        this.data = data;
        this.valor=valor;
    }
    
    

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }
    
}
