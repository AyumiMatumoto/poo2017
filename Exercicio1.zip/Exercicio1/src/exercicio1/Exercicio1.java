/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio1;

import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author FamiliaPoli
 */
public class Exercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Gerente gerente = new Gerente("Gabrielle Angeli Poli", "1111", 2000);
       // gerente.setSalario(2000.0);
        gerente.setSenha(123);
        //double s = gerente.getBonificacao();
        //System.out.println(s);
        Funcionario f = new Funcionario("Carolina Ayumi Matumoto", "2222", 2000);
        Date x=new Date();
        x.getTime();
        Venda v = new Venda(f, x,200);
        
        gerente.getBonificacao();
        f.getBonificacao();
        System.out.println("Salario Gerente: R$"+gerente.getSalario());
        System.out.println("Salario Funcionario: R$"+f.getSalario());
        Scanner scan = new Scanner(System.in);
        int i = scan.nextInt();
        if(gerente.autentica(i)==true)
        {
            System.out.println("Informações da venda: \n Data: "+ v.getData()+"\n Funcionario que realizou a venda: " +v.getFuncionario().getNome()); 
        }
        else
        {
            System.out.println("Acesso Negado!");
        }
        
        
               
    }
    
}
